---
name: Listing request
about: Request a listing
title: '[Listing] Request listing for {ADD TOKEN NAME HERE}'
labels: listing
assignees: Chef-Chungus
---

### DO NOT SUBMIT A LISTING REQUEST ON GITHUB - WE WILL LIST ANY PROJECT THAT HAS AN IFO/POOL/FARM

Please apply here instead: https://docs.google.com/forms/d/e/1FAIpQLScGdT5rrVMr4WOWr08pvcroSeuIOtEJf1sVdQGVdcAOqryigQ/viewform

Any Listing issues/PRs will be closed.
